import 'package:flutter/material.dart';

//ATALHO PARA CRIAR A CLASSE STATE
//stl

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form( 
          key: _formkey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            //crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Stack(
                  children: [
                    Image.asset("logo_ecotrack.png",
                    height: 150,
                    fit: BoxFit.cover,
                    ),
                    Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            const Color.fromARGB(255, 136, 178, 137),
                            const Color.fromARGB(255, 226, 249, 152)
                            ]
                          )
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 150,
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'E-mail',
                  prefix: Icon(
                    Icons.email
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(
                      color: Color.fromARGB(255, 5, 110, 14),
                      width: 6.5,
                      ),
                    ),
                  ),
                ),
              
            ], 
          )
        ),
      ),
    );
  }
}